import pandas as pd 
import numpy as np
def probability(df):
    s = np.sum(df, axis=0)
    print("\n **** \n")
    m = len(df)
    print("\n type(m) \n",type(m), type(s),"\n \t m nd s",m,s,"\n")
    mu = int(s)/int(m)
    print("\n **** \n")
    vr = np.sum((df - mu)**2, axis=0)
    print("\n **** \n")
    variance = vr/m
    print("\n **** \n")
    var_dia = np.diag(variance)
    print("\n **** \n")
    k = len(mu)
    print("\n **** \n")
    X = df - mu
    p = 1/((2*np.pi)**(k/2)*(np.linalg.det(var_dia)**0.5))* np.exp(-0.5* np.sum(X @ np.linalg.pinv(var_dia) * X,axis=1))
    return p

data = pd.read_csv("Twitter_volume_GOOG.csv")
print(data.head)
s = np.sum(data, axis=1)
d=s
print("Value os S = ",np.sum(d))

p =probability(d)
print("probability = ",p)
